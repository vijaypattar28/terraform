# lambda fucntion takes two arguments

def hello(event, context):
    print("Hello Everyone. This is built using Terraform")